package org.example;

import Domio.Pessoa;

public class Main {

    public static void main(String args[]) {

        Pessoa pessoa = new Pessoa.PessoaBuilder()
                .setprimeiroNome("Gutavo")
                .setsegundoNome("Marques")
                .setnomePai("Fernando")
                .setnomeMae("Adriana")
                .setidade(19)
                .build();
        System.out.println(pessoa);
    }
}
