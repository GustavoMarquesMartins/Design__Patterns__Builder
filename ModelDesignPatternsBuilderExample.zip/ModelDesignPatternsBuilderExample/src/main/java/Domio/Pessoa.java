package Domio;

public class Pessoa {

    private String primeiroNome;
    private String segundoNome;
    private String nomePai;
    private String nomeMae;
    private Integer idade;

    @Override
    public String toString() {
        return "PessoaBuilder{" +
                "primeiroNome='" + primeiroNome + '\'' +
                ", segundoNome='" + segundoNome + '\'' +
                ", nomePai='" + nomePai + '\'' +
                ", nomeMae='" + nomeMae + '\'' +
                ", idade=" + idade +
                '}';
    }

    public Pessoa(String primeiroNome, String segundoNome, String nomePai, String nomeMae, Integer idade) {
        this.primeiroNome = primeiroNome;
        this.segundoNome = segundoNome;
        this.nomePai = nomePai;
        this.nomeMae = nomeMae;
        this.idade = idade;
    }

    public static class PessoaBuilder {
        private String primeiroNome;
        private String segundoNome;
        private String nomePai;
        private String nomeMae;
        private Integer idade;


        public PessoaBuilder setprimeiroNome(String primeiroNome) {
            this.primeiroNome = primeiroNome;
            return this;
        }

        public PessoaBuilder setsegundoNome(String segundoNome) {
            this.segundoNome = segundoNome;
            return this;
        }

        public PessoaBuilder setnomeMae(String nomeMae) {
            this.nomeMae = nomeMae;
            return this;
        }

        public PessoaBuilder setnomePai(String nomePai) {
            this.nomePai = nomePai;
            return this;
        }

        public PessoaBuilder setidade(Integer idade) {
            this.idade = idade;
            return this;
        }

        public Pessoa build() {
            return new Pessoa(primeiroNome, segundoNome, nomePai, nomeMae, idade);
        }
    }
}